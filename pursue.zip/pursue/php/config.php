<?php
$host = "localhost";
$userName = "root";
$password = "";
$dbName = "quiz";

// Create database connection
$con = mysqli_connect($host, $userName, $password, $dbName);

// Error Handler
if (mysqli_connect_errno()) {
printf("Connessione fallita: %s\n", mysqli_connect_errno());
exit();
}
echo "Connessione effettuata con successo!";

?>